#!/bin/bash
cd "$(dirname "$0")"
exec ./bin/moniqi start "${1:-dev}"
