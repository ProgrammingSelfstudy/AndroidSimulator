#!/bin/bash
# One-time setup of a moniqi VM on this Mac (Apple silicon). Needs internet for the downloads.
set -euo pipefail
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine . 2>/dev/null || true
M=./bin/moniqi
NAME="${1:-dev}"
$M create "$NAME" --cpus 4 --memory-mib 2048 --disk-gib 16
$M build-image "$NAME" --guest-init guest/moniqi-init --guest-agent guest/moniqi-agent
$M pull-android "$NAME"
$M config "$NAME" --resolution 540x960 --dpi 240 --fps 20 --trim on
echo
echo "done. start it with:  ./bin/moniqi start $NAME"
