moniqi for Apple silicon (M1/M2/M3...) - macOS 13 or later

1. ./setup.sh            first time only; downloads the kernel and Android image (~1 GB)
2. ./start.sh            opens the emulator window (Ctrl-C in the terminal = clean shutdown)

Install apps: drag an .apk onto the window, or  ./bin/moniqi install app.apk
  (needs adb:  brew install --cask android-platform-tools)
Tune:  ./bin/moniqi config dev --resolution 720x1280 --dpi 320 --fps 30   (restart to apply)
Networking is built in (follows the Mac's own VPN/proxy); adb is on 127.0.0.1:5555.

If macOS says the binary is damaged/unverified:
  xattr -dr com.apple.quarantine .
